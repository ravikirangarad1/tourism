package connection;

public interface Provider {
	String CONNECTION_URL="jdbc:mysql://localhost/tourism";
	String USERNAME="root";
	String PASSWORD="";
}
